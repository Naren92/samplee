const express = require('express');
const bodyParser =  require('body-parser');
const product = require('./product');

var app = express();
app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded( { extended: true }));
app.use(product);

app.listen(4000, () => {
    console.log('server started on port 4000');
});