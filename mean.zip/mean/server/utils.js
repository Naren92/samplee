
function createResponse(error, dbResult) {
    var result = {};
    if (error == null || error == undefined) {
        result['status'] = 'success';
        result['data'] = dbResult;
    } else {
        result['status'] = 'error';
        result['message'] = 'error occured';
    }

    return result;
}

module.exports = {
    createResponse: createResponse
};