const mysql = require('mysql');

function connectDB() {
    var connection = mysql.createConnection({
        host: 'localhost',
        user: 'root',
        password: 'root',
        database: 'dac_aug_2018',
        port: 3306
    });

    return connection;
}

module.exports = {
    connectDB: connectDB
};