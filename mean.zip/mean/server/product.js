const express = require('express');
const db = require('./database');
const utils = require('./utils');

var router = express.Router();

router.get('/product', (request, response) => {
    var connection = db.connectDB();
    var statement = `select productId, title, description, price, brand from Product`;
    connection.query(statement, (error, dbResult) => {
        connection.end();
        response.send(utils.createResponse(error, dbResult));
    });
});

router.post('/product', (request, response) => {
    var connection = db.connectDB();
    var title = request.body.title;
    var description = request.body.description;
    var price = request.body.price;
    var brand = request.body.brand;

    var statement = `insert into Product (title, description, price, brand) values ('${title}', '${description}', ${price}, '${brand}')`;
    connection.query(statement, (error, dbResult) => {
        connection.end();
        response.send(utils.createResponse(error, dbResult));
    });
});

router.put('/product/:id', (request, response) => {
    var connection = db.connectDB();
    var id = request.params.id;
    var title = request.body.title;
    var description = request.body.description;
    var price = request.body.price;
    var brand = request.body.brand;

    var statement = `update Product set  title = '${title}', description = '${description}', price = ${price}, brand = '${brand}'  where productId = ${id}`;
    connection.query(statement, (error, dbResult) => {
        connection.end();
        response.send(utils.createResponse(error, dbResult));
    });
});

router.delete('/product/:id', (request, response) => {
    var connection = db.connectDB();
    var id = request.params.id;

    var statement = `delete from Product where productId = ${id}`;
    connection.query(statement, (error, dbResult) => {
        connection.end();
        response.send(utils.createResponse(error, dbResult));
    });
});

module.exports = router;